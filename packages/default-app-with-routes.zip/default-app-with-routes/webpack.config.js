const HtmlWebpackPlugin = require('html-webpack-plugin');
const path = require('path');
const DotenvFlow = require('dotenv-flow-webpack');
const { ModuleFederationPlugin } = require('webpack').container;
//const HotModuleReplacementPlugin = require('webpack').HotModuleReplacementPlugin;
const { MFLiveReloadPlugin } = require('@module-federation/fmr');

module.exports = (env, argv) => {
  const isProduction = argv.mode === 'production';

  devServer = isProduction
    ? {}
    : {
        historyApiFallback: true,
        hot: false,
        port: 3009,
        headers: {
          'Access-Control-Allow-Origin': '*',
        },
        static: path.join(__dirname, 'dist'),
      };

  const plugins = [
    new ModuleFederationPlugin({
      name: 'test3',
      filename: 'remoteEntry.js',
      exposes: {
        './App': './src/Routes',
      },
      shared: {
        react: { singleton: true, requiredVersion: '18.2.0' },
        'react-dom': { singleton: true, requiredVersion: '18.2.0' },
        'react-router-dom': { singleton: true },
      },
    }),
    new HtmlWebpackPlugin({
      template: './src/index.html',
      publicPath: '/',
    }),
  ];

  if (!isProduction) {
    plugins.push(
      new MFLiveReloadPlugin({
        port: 3009, // the port your app runs on
        container: 'test3', // the name of your app, must be unique
        standalone: true, // false uses chrome extention
      })
    );
    plugins.push(
      new DotenvFlow({
        node_env: argv.mode,
      })
    );
    //plugins.push(new HotModuleReplacementPlugin());
  }

  return {
    entry: './src/index',
    mode: isProduction ? 'production' : 'development',
    output: {
      publicPath: 'auto',
    },

    module: {
      rules: [
        {
          test: /\.(js|jsx|ts|tsx)$/,
          exclude: /node_modules/,
          use: [
            {
              loader: 'swc-loader',
            },
          ],
        },
        {
          test: /\.css$/,
          use: ['style-loader', 'css-loader'],
        },
      ],
    },
    resolve: {
      extensions: ['.js', '.jsx', '.ts', '.tsx'],
      modules: [path.resolve(__dirname, 'src'), 'node_modules'],
    },
    plugins,
    devServer,
  };
};
