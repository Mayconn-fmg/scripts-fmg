### All your hooks should be here

You should follow the follow structure:

- use-hook.ts -> a filename in snake-case

### Examples of use

Here you should add the use of your hook

```
  const {multiplyByTwo, value} = useMultiply(2);

  <StyledContainer>
    {title}
    <List goodPractices={goodPractices}></List>
    <p>Value: {value}</p>
    <button onClick={multiplyByTwo}>Multiply by two</button>
  </StyledContainer>
```
