import { useState } from 'react';

function useMultiply(initialValue: any) {
  const [value, setValue] = useState(initialValue);

  const multiplyByTwo = () => {
    setValue(value * 2);
  };

  return { value, multiplyByTwo };
}

export default useMultiply;
