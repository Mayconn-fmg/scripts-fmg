export type GoodPractice = {
  id: number;
  name: string;
};
