import React, { Suspense, lazy } from 'react';
import { Route, Routes, BrowserRouter, useNavigate } from 'react-router-dom';
import * as Pages from './pages';

function toKebabCase(str: string) {
  return str.replace(/([a-z])([A-Z])/g, '$1-$2').toLowerCase();
}

const AppRoutes = () => {
  return (
    <Suspense fallback={<div>Loading...</div>}>
      <Routes>
        {Object.entries(Pages).map(([key, Component]) => {
          const path = `/${toKebabCase(key)}`;
          const LazyComponent = lazy(() => Promise.resolve({ default: Component }));
          return <Route key={path} path={path} element={<LazyComponent />} />;
        })}
        <Route path="*" element={<p>Wrong route</p>} />
      </Routes>
    </Suspense>
  );
};

export default AppRoutes;
