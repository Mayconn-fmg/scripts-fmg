export { default as PageExample } from './page-example/PageExample';
