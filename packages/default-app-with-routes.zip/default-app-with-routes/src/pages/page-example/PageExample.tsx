import React from 'react';
import { StyledContainer } from './PageExample.styles';
import { ComponentName } from 'components/component-name';
import { GoodPractice } from 'types/GoodPractice';

export default function PageExample() {
  const goodPractices: GoodPractice[] = [
    {
      id: 1,
      name: 'Good practice 1',
    },
    {
      id: 2,
      name: 'Good practice 2',
    },
  ];

  return (
    <StyledContainer>
      <ComponentName title="List Of Good Practices" goodPractices={goodPractices} />
    </StyledContainer>
  );
}
