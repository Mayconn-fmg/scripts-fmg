import styled from '@emotion/styled';
import { Container } from '@mui/material';

export const StyledContainer = styled(Container)`
  width: 100%;
  height: 100vh;
  background-color: #f1f1f1;
`;
