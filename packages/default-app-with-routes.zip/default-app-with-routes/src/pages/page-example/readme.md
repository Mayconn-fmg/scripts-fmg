### All your pages should be here

You should follow the follow structure:

- page-name -> a folder with the page name in snake-case
- PageName.tsx -> your react page in PascalCase
- PageName.style.ts -> the styles of your page in PascalCase

### PageName.tsx

Use a functional component

### PageName.styles.ts

Use mui

### Important

There is a file called index.ts in the root of the pages folder.
You need to add the export of all pages you create there following the pattern:
`export { default as PageExample } from './page-example/PageExample';`
It is important to follow this pattern, this is the only way the routes will work as expected
