import React from 'react';
import { StyledContainer } from './ComponentName.style';
import { List } from './List';
import { GoodPractice } from '../../types/GoodPractice';

type IProps = {
  title: string;
  goodPractices: GoodPractice[];
};

function ComponentName(props: IProps) {
  const { title, goodPractices } = props;
  return (
    <StyledContainer>
      {title}
      <List goodPractices={goodPractices}></List>
    </StyledContainer>
  );
}

export { ComponentName };
