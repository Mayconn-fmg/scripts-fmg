### All your components should be here

You should follow the follow structure:

- component-name -> a folder with the component name in snake-case
- ComponentName.tsx -> your react component in PascalCase
- ComponentName.style.ts -> the styles of your component in PascalCase
- index.ts -> A file exporting everything you need to export

### ComponentName.tsx

Use a functional component

### ComponentName.styles.ts

Use mui

### index.ts

The export should follow this pattern
export { ComponentName } from './ComponentName';

### Examples of use

Here you should add the use of your component

```
  import { GoodPractice } from 'types/GoodPractice';
  const goodPractices: GoodPractice[] = [
    {
      id: 1,
      name: 'Good practice 1',
    }
  ];

  <ComponentName title="List Of Good Practices" goodPractices={goodPractices} />

```
