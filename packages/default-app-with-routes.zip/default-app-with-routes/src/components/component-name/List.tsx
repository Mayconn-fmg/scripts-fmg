import React from 'react';
import { List as MaterialList, ListItem } from '@mui/material';
import { GoodPractice } from '../../types/GoodPractice';

type IProps = {
  goodPractices: GoodPractice[];
};

function List(props: IProps) {
  const { goodPractices } = props;
  return (
    <MaterialList>
      {goodPractices.map((item) => (
        <ListItem key={item.id}>{item.name}</ListItem>
      ))}
    </MaterialList>
  );
}

export { List };
